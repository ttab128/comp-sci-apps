package lab6;

public class Lab6App {
	public static void main() {
		
	PhoneBookEntry entry = new PhoneBookEntry();
	
	System.out.println(entry.toString());
	}
}