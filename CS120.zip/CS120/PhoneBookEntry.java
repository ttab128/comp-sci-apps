package lab6;

public class PhoneBookEntry {
	public static void main(){
	String firstName = new String("None");
	String lastName = new String("None");	
	String phoneNumber = new String("516-555-5555");
	String birthDate = new String("01/01/2013");
	char relationship = 'X';

	}

		

	public String toString() {	
		String newString = new String(firstName + ", " + lastName + "\n" + relationship + "\n" + phoneNumber + "\n" + birthDate);
		return newString;
	}

}


